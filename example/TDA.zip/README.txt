TwitterDataAnalytics.zip - Contains Java examples from Chapters 2, 4, and 5.
TwitterDataAnalytics.war - Contains web examples from Chapter 5.
Chapter3 - Contains JavaScript examples from Chapter 3.

To use TwitterDataAnalytics.war, deploy the war file to a Tomcat 8 deployment. Instructions on installing and configuring Tomcat can be found here: https://tomcat.apache.org/tomcat-8.0-doc/index.html. 

TwitterDataAnalytics.zip is a Netbeans project. It has been compiled and tested with Netbeans 7.3. 