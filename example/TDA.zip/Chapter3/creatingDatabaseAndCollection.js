//MongoDB will create the collection 'tweets'.
db.createCollection('tweets');
